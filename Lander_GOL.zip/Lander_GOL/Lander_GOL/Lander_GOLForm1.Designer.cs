﻿namespace Lander_GOL
{
    partial class Lander_GOLForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.FlowLayoutPanel();
            this.btnGenGrid = new System.Windows.Forms.Button();
            this.txtStrengh = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTimes = new System.Windows.Forms.TextBox();
            this.btnPulsar = new System.Windows.Forms.Button();
            this.btnGlider = new System.Windows.Forms.Button();
            this.btnBlinker = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnOnce = new System.Windows.Forms.Button();
            this.lblAlive = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDead = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblRed = new System.Windows.Forms.Label();
            this.lblBlue = new System.Windows.Forms.Label();
            this.lblMagenta = new System.Windows.Forms.Label();
            this.lblGreen = new System.Windows.Forms.Label();
            this.lblYellow = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Margin = new System.Windows.Forms.Padding(4);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1552, 971);
            this.pnlMain.TabIndex = 0;
            // 
            // btnGenGrid
            // 
            this.btnGenGrid.Location = new System.Drawing.Point(22, 977);
            this.btnGenGrid.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenGrid.Name = "btnGenGrid";
            this.btnGenGrid.Size = new System.Drawing.Size(164, 59);
            this.btnGenGrid.TabIndex = 1;
            this.btnGenGrid.Text = "Generate Grid";
            this.btnGenGrid.UseVisualStyleBackColor = true;
            this.btnGenGrid.Click += new System.EventHandler(this.btnGenGrid_Click);
            // 
            // txtStrengh
            // 
            this.txtStrengh.Location = new System.Drawing.Point(1564, 129);
            this.txtStrengh.Margin = new System.Windows.Forms.Padding(4);
            this.txtStrengh.Name = "txtStrengh";
            this.txtStrengh.Size = new System.Drawing.Size(142, 31);
            this.txtStrengh.TabIndex = 2;
            this.txtStrengh.Text = "4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1560, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter Strength:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1560, 65);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Values 2 - 20";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(1564, 165);
            this.btnGenerate.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(152, 65);
            this.btnGenerate.TabIndex = 5;
            this.btnGenerate.Text = "Generate Random";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1560, 100);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Lower The Stronger";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(1476, 991);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(122, 38);
            this.btnStart.TabIndex = 7;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1284, 998);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Times:";
            // 
            // txtTimes
            // 
            this.txtTimes.Location = new System.Drawing.Point(1368, 995);
            this.txtTimes.Margin = new System.Windows.Forms.Padding(4);
            this.txtTimes.Name = "txtTimes";
            this.txtTimes.Size = new System.Drawing.Size(100, 31);
            this.txtTimes.TabIndex = 9;
            this.txtTimes.Text = "5";
            // 
            // btnPulsar
            // 
            this.btnPulsar.Location = new System.Drawing.Point(12, 148);
            this.btnPulsar.Margin = new System.Windows.Forms.Padding(6);
            this.btnPulsar.Name = "btnPulsar";
            this.btnPulsar.Size = new System.Drawing.Size(150, 44);
            this.btnPulsar.TabIndex = 10;
            this.btnPulsar.Text = "Pulsar";
            this.btnPulsar.UseVisualStyleBackColor = true;
            this.btnPulsar.Click += new System.EventHandler(this.btnPulsar_Click);
            // 
            // btnGlider
            // 
            this.btnGlider.Location = new System.Drawing.Point(12, 92);
            this.btnGlider.Margin = new System.Windows.Forms.Padding(6);
            this.btnGlider.Name = "btnGlider";
            this.btnGlider.Size = new System.Drawing.Size(150, 44);
            this.btnGlider.TabIndex = 11;
            this.btnGlider.Text = "Glider";
            this.btnGlider.UseVisualStyleBackColor = true;
            this.btnGlider.Click += new System.EventHandler(this.btnGlider_Click);
            // 
            // btnBlinker
            // 
            this.btnBlinker.Location = new System.Drawing.Point(12, 37);
            this.btnBlinker.Margin = new System.Windows.Forms.Padding(6);
            this.btnBlinker.Name = "btnBlinker";
            this.btnBlinker.Size = new System.Drawing.Size(150, 44);
            this.btnBlinker.TabIndex = 12;
            this.btnBlinker.Text = "Blinker";
            this.btnBlinker.UseVisualStyleBackColor = true;
            this.btnBlinker.Click += new System.EventHandler(this.btnBlinker_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBlinker);
            this.groupBox1.Controls.Add(this.btnPulsar);
            this.groupBox1.Controls.Add(this.btnGlider);
            this.groupBox1.Location = new System.Drawing.Point(1562, 260);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(184, 244);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Designs";
            // 
            // btnOnce
            // 
            this.btnOnce.Location = new System.Drawing.Point(1605, 993);
            this.btnOnce.Name = "btnOnce";
            this.btnOnce.Size = new System.Drawing.Size(159, 36);
            this.btnOnce.TabIndex = 14;
            this.btnOnce.Text = "Update Once";
            this.btnOnce.UseVisualStyleBackColor = true;
            this.btnOnce.Click += new System.EventHandler(this.btnOnce_Click);
            // 
            // lblAlive
            // 
            this.lblAlive.AutoSize = true;
            this.lblAlive.Location = new System.Drawing.Point(77, 32);
            this.lblAlive.Name = "lblAlive";
            this.lblAlive.Size = new System.Drawing.Size(48, 25);
            this.lblAlive.TabIndex = 16;
            this.lblAlive.Text = "000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(119, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 25);
            this.label5.TabIndex = 17;
            this.label5.Text = "Dead:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 25);
            this.label6.TabIndex = 18;
            this.label6.Text = "Alive:";
            // 
            // lblDead
            // 
            this.lblDead.AutoSize = true;
            this.lblDead.Location = new System.Drawing.Point(194, 32);
            this.lblDead.Name = "lblDead";
            this.lblDead.Size = new System.Drawing.Size(48, 25);
            this.lblDead.TabIndex = 19;
            this.lblDead.Text = "000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(248, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 25);
            this.label7.TabIndex = 20;
            this.label7.Text = "Yellow:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblRed);
            this.groupBox3.Controls.Add(this.lblBlue);
            this.groupBox3.Controls.Add(this.lblMagenta);
            this.groupBox3.Controls.Add(this.lblGreen);
            this.groupBox3.Controls.Add(this.lblYellow);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.lblAlive);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.lblDead);
            this.groupBox3.Location = new System.Drawing.Point(193, 972);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1087, 64);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Stats";
            // 
            // lblRed
            // 
            this.lblRed.AutoSize = true;
            this.lblRed.Location = new System.Drawing.Point(861, 32);
            this.lblRed.Name = "lblRed";
            this.lblRed.Size = new System.Drawing.Size(48, 25);
            this.lblRed.TabIndex = 29;
            this.lblRed.Text = "000";
            // 
            // lblBlue
            // 
            this.lblBlue.AutoSize = true;
            this.lblBlue.Location = new System.Drawing.Point(580, 32);
            this.lblBlue.Name = "lblBlue";
            this.lblBlue.Size = new System.Drawing.Size(48, 25);
            this.lblBlue.TabIndex = 28;
            this.lblBlue.Text = "000";
            // 
            // lblMagenta
            // 
            this.lblMagenta.AutoSize = true;
            this.lblMagenta.Location = new System.Drawing.Point(744, 32);
            this.lblMagenta.Name = "lblMagenta";
            this.lblMagenta.Size = new System.Drawing.Size(48, 25);
            this.lblMagenta.TabIndex = 27;
            this.lblMagenta.Text = "000";
            // 
            // lblGreen
            // 
            this.lblGreen.AutoSize = true;
            this.lblGreen.Location = new System.Drawing.Point(459, 32);
            this.lblGreen.Name = "lblGreen";
            this.lblGreen.Size = new System.Drawing.Size(48, 25);
            this.lblGreen.TabIndex = 26;
            this.lblGreen.Text = "000";
            // 
            // lblYellow
            // 
            this.lblYellow.AutoSize = true;
            this.lblYellow.Location = new System.Drawing.Point(331, 32);
            this.lblYellow.Name = "lblYellow";
            this.lblYellow.Size = new System.Drawing.Size(48, 25);
            this.lblYellow.TabIndex = 25;
            this.lblYellow.Text = "000";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(798, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 25);
            this.label11.TabIndex = 24;
            this.label11.Text = "Red:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(634, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 25);
            this.label9.TabIndex = 23;
            this.label9.Text = "Magenta: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(513, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 25);
            this.label10.TabIndex = 22;
            this.label10.Text = "Blue:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(385, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 25);
            this.label8.TabIndex = 21;
            this.label8.Text = "Green:";
            // 
            // Lander_GOLForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1770, 1041);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnOnce);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtTimes);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtStrengh);
            this.Controls.Add(this.btnGenGrid);
            this.Controls.Add(this.pnlMain);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Lander_GOLForm1";
            this.Text = "Game Of Life";
            this.Load += new System.EventHandler(this.Lander_GOLForm1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel pnlMain;
        private System.Windows.Forms.Button btnGenGrid;
        private System.Windows.Forms.TextBox txtStrengh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTimes;
        private System.Windows.Forms.Button btnPulsar;
        private System.Windows.Forms.Button btnGlider;
        private System.Windows.Forms.Button btnBlinker;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnOnce;
        private System.Windows.Forms.Label lblAlive;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblDead;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblRed;
        private System.Windows.Forms.Label lblBlue;
        private System.Windows.Forms.Label lblMagenta;
        private System.Windows.Forms.Label lblGreen;
        private System.Windows.Forms.Label lblYellow;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
    }
}

