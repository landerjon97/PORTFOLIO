﻿/*
 * Author: Jonathan Lander
 * Class: CIS 244
 * Purpose: To make the game of life.
 * Date: 3/24/17
 * EHS: 15
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lander_GOL
{

    public partial class Lander_GOLForm1 : Form
    {
        //rows and columns for the panel
        private const int CELL_SIZE = 12;
        private const int ROWS = 42;
        private const int COLS = 62;
        //array used to see age of cells
        private int[,] floor = new int[ROWS, COLS];
        private int[,] age = new int[ROWS, COLS];
        //for drawing on panel
        Graphics gr;
        Pen paintBrush;
        Brush brush;
        //random to generate strength seed
        Random rand = new Random();


        public Lander_GOLForm1()
        {
            //set colors and initialize nessesary components needed to draw to on the panel
            InitializeComponent();
            gr = pnlMain.CreateGraphics();
            paintBrush = new Pen(System.Drawing.Color.Black);
            brush = new SolidBrush(Color.White);
        }
        //Method for generating the grid
        //passes 1 parameters one to make a grid based on how many cells user wishes to have
        public void generateGrid(int pStrength)
        {
            Rectangle rec = new Rectangle();
            //drawCell stores the random integer
            int drawCell;
            //for loops is used to generate each row and giving values to the array floor which is
            //used for generating randomly living cells
            for (int i = 1; i < ROWS - 1; i++)
            {
                for (int j = 1; j < COLS - 1; j++)
                {
                    drawCell = rand.Next(pStrength);
                    //generates a grid 12x12 for each cell
                    
                    rec = new Rectangle(j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                    brush = new SolidBrush(Color.White);
                    gr.FillRectangle(brush, rec);
                    gr.DrawRectangle(paintBrush, rec);

                    //sets all floor values to zero
                    floor[i, j] = 0;
                    //tests to see if random value is zero or any other random digit if so change floor to 1.
                    if (drawCell == 1)
                    {
                        brush = new SolidBrush(Color.Yellow);
                        gr.FillRectangle(brush, j * CELL_SIZE+1, i * CELL_SIZE+1, CELL_SIZE-1, CELL_SIZE-1);
                        
                        age[i, j] = 1;
                        floor[i, j] = 1;
                    }
                    
                }
            }
            
        }
        //generation of a grid with no living cells in it, can be used to see what it will look like prior
        private void btnGenGrid_Click(object sender, EventArgs e)
        {
            update();
            reset();
            generateGrid(0);
        }
        //This method is used to generate a random grid based on the value in txtStrength.Text
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            reset();
            //default the value to 4 just in case user does not change the text box
            int strength = 4;
            
            try
            {
                strength = int.Parse(txtStrengh.Text);

                //if the values entered if above 20 just set it to twenty and call it a day.
                if(strength >= 20) 
                {
                    strength = 20;
                }
                
                generateGrid(strength);
            }
            catch
            {
                //makes sure user enters a integer
                MessageBox.Show("Please Enter values between 1-20");
            }


        }

        private void Lander_GOLForm1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        /*
         * Update method is used to update the grid when button start is clicked
         * I think I should pass graphics into a whole entire class seperate from the button use.
         */
        public void update()
        {
            Rectangle rec1 = new Rectangle();
            for (int i = 1; i < ROWS - 1; i++)
            {
                for (int j = 1; j < COLS - 1; j++)
                {
                    rec1 = new Rectangle(j * CELL_SIZE + 1, i * CELL_SIZE + 1, CELL_SIZE - 1, CELL_SIZE - 1);


                    /*
                     * This tests to see the age of each cell
                     * 0: white (dead)
                     * 1: yellow
                     * 2: green
                     * 3: blue
                     * 4: magenta
                     * 5: red 
                     * anything older stay red.
                     */
                    if (age[i, j] == 1)
                    {

                        floor[i, j] = 1;
                        brush = new SolidBrush(Color.Yellow);
                        gr.FillRectangle(brush, rec1);

                    }

                    else if (age[i, j] == 0)
                    {
                        floor[i, j] = 0;
                        brush = new SolidBrush(Color.White);
                        gr.FillRectangle(brush, rec1);
                    }
                    else if (age[i, j] == 2)
                    {
                        floor[i, j] = 1;
                        brush = new SolidBrush(Color.Green);
                        gr.FillRectangle(brush, rec1);
                    }
                    else if (age[i, j] == 3)
                    {
                        floor[i, j] = 1;
                        brush = new SolidBrush(Color.Blue);
                        gr.FillRectangle(brush, rec1);
                    }
                    else if (age[i, j] == 4)
                    {
                        floor[i, j] = 1;
                        brush = new SolidBrush(Color.Magenta);
                        gr.FillRectangle(brush, rec1);
                    }
                    else if (age[i, j] >= 5)
                    {
                        floor[i, j] = 1;
                        brush = new SolidBrush(Color.Red);
                        gr.FillRectangle(brush, rec1);
                    }
                    
                }
            }
            
        }
        /*
         * Start is where the magic happens
         * When user presses start it takes them to this class where
         * goes throught adding relating sides up
         * if its 4 or above it dies if its 1 or lower it dies
         * if its 3 it becomes alive
         * if its 2 or 3 it stays alive and it will age
         */
        public void start()
        {

            for (int i = 1; i < ROWS - 1; i++)
            {
                for (int j = 1; j < COLS - 1; j++)
                {
                    int isAlive = 0;

                    isAlive = floor[i - 1, j - 1] + floor[i - 1, j] + floor[i - 1, j + 1] +
                              floor[i, j - 1] + floor[i, j + 1] + floor[i + 1, j - 1] +
                              floor[i + 1, j] + floor[i + 1, j + 1];

                    if (isAlive <= 1 || isAlive >= 4)
                    {

                        age[i, j] = 0;

                    }
                    else if (isAlive == 3 && floor[i, j] == 0)
                    {

                        age[i, j] = 1;

                    }
                    else if (floor[i, j] == 1 && isAlive == 2 || isAlive == 3)
                    {

                        age[i, j]++;
                    }

                }
            }

        }
        //reset is called to reset the grid and set all of the values that 
        //change 2 zero
        public void reset()
        {
            for (int i = 1; i < ROWS - 1; i++)
            {
                for (int j = 1; j < COLS - 1; j++)
                {
                    floor[i, j] = 0;
                    age[i, j] = 0;
                }
            }
        }
        /*
         * the following methods are used to generate designs accordingly
         * blicker is just a 3 lines of living cells
         * glider glides across the grid
         * pulsar fluxates
         * NOTE: only commenting on glider and blinker because pulsar is set up the same as glider.
         */
        public void blinker()
        {
            //resets the grid so they dont interfere
            //NOTE: age will be set to zero as well when it is reset so no need of a for loop to to do that.
            reset();
            //then redraws grid to get rid of the cells
            update();
            Rectangle rec = new Rectangle();
            //go through grid labeling them all with zero execpt....
            for (int i = 1; i < ROWS - 1; i++)
            {
                for (int j = 1; j < COLS - 1; j++)
                {
                    floor[i, j] = 0;
                    age[i, j] = 0;
                    rec = new Rectangle(j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                    gr.DrawRectangle(paintBrush, rec);
                    //for values in columns 29, 30, and 31 the method will label those values as 1
                    //in row 21
                    if (i == 21 && (j == 29 || j == 30 || j == 31))
                    {
                        floor[i, j] = 1;
                        age[i, j] = 1;
                        brush = new SolidBrush(Color.Yellow);
                        gr.FillRectangle(brush, j * CELL_SIZE + 1, i * CELL_SIZE + 1, CELL_SIZE - 1, CELL_SIZE - 1);
                    }

                }

            }
        }
        public void glider()
        {
            //reset grid
            reset();
            //update grid to get rid of previous
            update();
            //I created a array of what the glider looks like. Will be used later.
            int[,] glider = new int[3, 3] { {0,0,1},
                                            {1,0,1},
                                            {0,1,1} };
            Rectangle rec = new Rectangle();
            //goes through the grid labeling everything as zero and drawing it.
            for (int i = 1; i < ROWS - 1; i++)
            {
                for (int j = 1; j < COLS - 1; j++)
                {
                    floor[i, j] = 0;
                    age[i, j] = 0;
                    rec = new Rectangle(j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                    gr.DrawRectangle(paintBrush, rec);
                }
            }
            //I created another for loop for the center of the floor.
            //here is where i put in the glider array so it will be displayed
            for (int i = 19; i <= 21; i++)
            {
                for (int j = 29; j <= 31; j++)
                {
                    //I must subtract 19 and 29 because the array is only 13x13 so values above 
                    //that will be an out of range.
                    floor[i, j] = glider[i - 19, j - 29];
                    rec = new Rectangle(j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                    gr.DrawRectangle(paintBrush, rec);
                    //for values that are 1 it simply fills in the rectangles
                    if (floor[i, j] == 1)
                    {
                        age[i, j] = 1;
                        brush = new SolidBrush(Color.Yellow);
                        gr.FillRectangle(brush, j * CELL_SIZE + 1, i * CELL_SIZE + 1, CELL_SIZE - 1, CELL_SIZE - 1);
                    }
                }
            }
        }
        public void pulsar()
        {
            reset();
            update();
            int[,] pulsar = new int[13, 13] { { 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0 },
                                              { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                                              { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                                              { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                                              { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                                              { 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0 },
                                              { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                                              { 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0 },
                                              { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                                              { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                                              { 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1 },
                                              { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                                              { 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0 } };
            Rectangle rec = new Rectangle();
            for (int i = 1; i < ROWS - 1; i++)
            {
                for (int j = 1; j < COLS - 1; j++)
                {
                    floor[i, j] = 0;
                    age[i, j] = 0;
                    rec = new Rectangle(j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                    gr.DrawRectangle(paintBrush, rec);
                }
            }
            for (int i = 15; i <= 27; i++)
            {
                for (int j = 23; j <= 35; j++)
                {
                    floor[i, j] = pulsar[i - 15, j - 23];
                    rec = new Rectangle(j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
                    gr.DrawRectangle(paintBrush, rec);
                    if (floor[i, j] == 1)
                    {
                        age[i, j] = 1;
                        brush = new SolidBrush(Color.Yellow);
                        gr.FillRectangle(brush, j * CELL_SIZE + 1, i * CELL_SIZE + 1, CELL_SIZE - 1, CELL_SIZE - 1);
                    }
                }
            }

        }
    
        //btnState method is going to take how many times you want to update the random generated grid and update it.
        private void btnStart_Click(object sender, EventArgs e)
        {

            //construction of the class GOLCell
           
            //try parse this later
            int times = 5;
            try
            {
                times = int.Parse(txtTimes.Text);
            }
            catch
            {
                MessageBox.Show("please enter any integer except 0");
            }
            int currentTime = 1;
            bool live;

            //goes through number of times the user wishes it to go through
            while (currentTime <= times)
            {
                //calling methods from the class GOLCell
                //Noted that I dont seem to have FutureState and age working properly
                start();
                update();
                currentTime++;
                getStats();
                System.Threading.Thread.Sleep(200);
            }
        }
        //calls blinker method to be drawn
        private void btnBlinker_Click(object sender, EventArgs e)
        {
            blinker();
        }
        //calls glider method to be drawn
        private void btnGlider_Click(object sender, EventArgs e)
        {
            glider();
        }
        //calles pulsar method to be drawn
        private void btnPulsar_Click(object sender, EventArgs e)
        {
            pulsar();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnOnce_Click(object sender, EventArgs e)
        {
            start();
            update();
            getStats();
        }

        public void getStats()
        {

            /*
             * This tests to see the age of each cell
             * 0: white (dead)
             * 1: yellow
             * 2: green
             * 3: blue
             * 4: magenta
             * 5: red 
             * anything older stay red.
             */
            int alive = 0;
            int dead = 0;
            int yellow = 0;
            int green = 0;
            int blue = 0;
            int magenta = 0;
            int red = 0;
            for (int i = 1; i < ROWS - 1; i++)
            {
                for (int j = 1; j < COLS - 1; j++)
                {
                    if (floor[i, j] == 1)
                    {
                        alive++;
                        lblAlive.Text = alive.ToString();
                    }
                    if(floor[i,j] == 0)
                    {
                        dead++;
                        lblDead.Text = dead.ToString();
                    }
                    if(age[i, j] == 1)
                    {
                        yellow++;
                        lblYellow.Text = yellow.ToString();
                    }
                    if (age[i, j] == 2)
                    {
                        green++;
                        lblGreen.Text = green.ToString();
                    }
                    if (age[i, j] == 3)
                    {
                        blue++;
                        lblBlue.Text = blue.ToString();
                    }
                    if (age[i, j] == 4)
                    { 
                        magenta++;
                        lblMagenta.Text = magenta.ToString();
                    }
                    if (age[i, j] >= 5)
                    {
                        red++;
                        lblRed.Text = red.ToString();
                    }
                }
            }
        }

    }

    public class GOLCell
        {
            private Rectangle cell;
            private int isAlive;
            private int[,] futureState = new int[42, 62];
            private int[,] age = new int[42, 62];
            public void start(int[,] floor)
            {

                for (int i = 1; i < 41; i++)
                {
                    for (int j = 1; j < 61; j++)
                    {


                        isAlive = floor[i - 1, j - 1] + floor[i - 1, j] + floor[i - 1, j + 1] +
                                      floor[i, j - 1] + floor[i, j + 1] + floor[i + 1, j - 1] +
                                      floor[i + 1, j] + floor[i + 1, j + 1];

                        if (isAlive <= 1 || isAlive >= 4)
                        {
                            futureState[i, j] = 2;
                        }
                        else if (isAlive == 3 && floor[i, j] == 0)
                        {
                            futureState[i, j] = 3;
                        }
                        else if (isAlive == 2 || isAlive == 3)
                        {
                            futureState[i, j] = 1;
                        }


                    }
                }

            }

            public int[,] state(int[,] floor)
            {

                for (int i = 1; i < 41; i++)
                {
                    for (int j = 1; j < 61; j++)
                    {

                        if (futureState[i, j] == 1 && floor[i, j] != 0)
                        {
                            floor[i, j] = 1;

                        }
                        else if (futureState[i, j] == 2)
                        {
                            floor[i, j] = 0;
                        }
                        else if (futureState[i, j] == 3 && floor[i, j] == 0)
                        {
                            floor[i, j] = 1;

                        }
                    }
                }
                return floor;
            }
            public bool life(int[,] floor, int i, int j)
            {
                isAlive = floor[i - 1, j - 1] + floor[i - 1, j] + floor[i - 1, j + 1] +
                floor[i, j - 1] + floor[i, j + 1] + floor[i + 1, j - 1] +
                floor[i + 1, j] + floor[i + 1, j - 1];
                if (isAlive <= 1 || isAlive >= 4)
                {
                    return false;
                }
                else if (isAlive == 2 || isAlive == 3)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            public int futureAge(bool stillAlive, int pAge)
            {
                if (stillAlive == false)
                {
                    pAge = 0;
                }
                else
                {
                    pAge++;
                }
                return pAge;
            }

        }
}   









