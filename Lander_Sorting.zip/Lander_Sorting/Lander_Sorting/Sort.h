/*
Author: Jonathan Lander
Date: 4/12/17
Project: Sorting Algorithms
*/
#ifndef QUICKSORT_H
#define QUICKSORT_H
//much of this is like fileReader.h, most of the comments are in Sort.cpp
//I simply create the varaibles that will be used in Sort.cpp
//Along with the methods as well.
class QuickSort
{

private:
	int i;
	int j;
	int holder ;
	int pivot;
public:
	QuickSort();
	QuickSort(int *ptrArray, int left, int right);

	int Partition(int *ptrArray, int left, int right);
};

class Bubble
{
private:
	bool swapped;
	int temp;
	int i;
public:
	Bubble();
	Bubble(int *ptrArray, int elements);
};

class Insertion {
private:
	int holePosition;
	int valueToInsert;
public:
	Insertion();
	Insertion(int *ptrArray, int elements);
};
#endif
