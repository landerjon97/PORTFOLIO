/*
Author: Jonathan Lander
Date: 4/12/17
Project: Sorting Algorithms
*/
#ifndef FILEREADER_H
#define FILEREADER_H
#include <string>
#include <fstream>

using namespace std;
class FileReader
{
	//making values to be used later
private:
	string fileName = "";
	ifstream fileReaderObj;
	int *intArray = 0;
	//creating the methods that can be used in the main file. Will be created in FileReader.cpp
public:
	FileReader();
	FileReader(string pFile, int elements);
	void readFile();
	int* getIntArray();

};



#endif