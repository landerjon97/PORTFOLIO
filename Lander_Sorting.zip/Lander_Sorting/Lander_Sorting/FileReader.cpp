/*
Author: Jonathan Lander
Date: 4/12/17
Project: Sorting Algorithms
*/
#include "stdafx.h"
#include "FileReader.h"
//the default constructor does nothing
FileReader::FileReader() {

}
//The overloaded constructor takes a string and the amount of numbers a person inputs called elements
FileReader::FileReader(string pFile, int elements) {
	//set file name that was made in FileReader.h to pFile.
	fileName = pFile;
	//opens the file
	fileReaderObj.open(fileName);
	//creates the pointer allocating elements to it.
	intArray = new int[elements];

}
void FileReader::readFile() {
	//reading through the file.
	int count = 0;
	while (fileReaderObj >> intArray[count]) {
		count++;
	}

}
//returning the pointer when it is done.
int* FileReader::getIntArray() {
	return intArray;
}