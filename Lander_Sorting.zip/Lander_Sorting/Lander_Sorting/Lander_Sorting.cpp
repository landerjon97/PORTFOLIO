/*
Author: Jonathan Lander
Date: 4/12/17
Project: Sorting Algorithms
*/

#include "stdafx.h"
#include <iostream>
#include "FileReader.h"
#include "Sort.h"
#include <iostream>
#include <time.h>



using namespace std;
//just prints the pointer to the screen.
void printToScreen(int *intArrayPtr, int elements) {
	for (int i = 0; i < elements; i++) {
		cout << intArrayPtr[i] << endl;
	}
}


int main()
{
	//first i ask user to input how many values that will be used before the file is read
	int elements = 0;
	cout << "Please enter how many numbers you wish to sort: ";
	cin >> elements;
	cout << endl;
	//i construct a FileReader with the location and elements
	FileReader myReader("fivehundredThousand.txt", elements);
	//exit is used to exit the do/while loop and close the program.
	bool exit = false;
	//clock is used to see how long each algorithm takes
	clock_t t1, t2;
	//whatToDo is the case for the switch in the do/while loop
	int whatToDo;
	//next i read the file in and then set a pointer to the reader to get the values
	myReader.readFile();
	int *intArrayPtr = myReader.getIntArray();
	/*
	*************************************************************************************
	AS MENTION EARLIER YOU MAY HAVE TO REBUILD THE PROJECT IN ORDER FOR THEM ALL TO WORK!
	*************************************************************************************
	*/
	//start of the do while loop asked the question and user input the value asked
	do {


		cout << "Please choose one:\n";
		cout << "1. Bubble sort\n";
		cout << "2. Insertion Sort\n";
		cout << "3. Quick sort\n";
		cout << "4. Change how many numbers to do\n";
		cout << "5. exit\n";
		cin >> whatToDo;
		//switch started and is based around cases which are the number the user input
		switch (whatToDo) {
		case 1:
		{
			//starts the clock
			t1 = clock();
			//constructs the class and uses it
			Bubble bubble(intArrayPtr, elements);
			//ends clock
			t2 = clock();
			//I do not time how long it takes to print the values to screen
			printToScreen(intArrayPtr, elements);
			//changes the clock values to float then converts it to seconds and prints
			float diff((float)t2 - (float)t1);
			float seconds = diff / CLOCKS_PER_SEC;
			cout << "time: "<< seconds << endl;
			//break tells it to leave the switch.
			break;
		}
		//Repeat as last
		case 2:
		{
			t1 = clock();
			Insertion insertion(intArrayPtr, elements);
			t2 = clock();
			printToScreen(intArrayPtr, elements);
			float diff((float)t2 - (float)t1);
			float seconds = diff / CLOCKS_PER_SEC;
			cout << "time: " << seconds << endl;
			break;
		}
		case 3:
		{
			t1 = clock();
			QuickSort quicksort(intArrayPtr, 0, elements - 1);
			t2 = clock();
			printToScreen(intArrayPtr, elements);
			float diff((float)t2 - (float)t1);
			float seconds = diff / CLOCKS_PER_SEC;
			cout << "time: " << seconds << endl;
			break;
		}
		//changing elements which should never be used because lack of try catch
		case 4:
		{
			cout << "Please enter how many numbers you wish to sort: ";
			cin >> elements;
			cout << endl;
			break;
		}
		//5 just exits the program.

		case 5:
		{
			exit = true;
			break;
		}
		}

	} while (exit == false);




	return 0;
}
