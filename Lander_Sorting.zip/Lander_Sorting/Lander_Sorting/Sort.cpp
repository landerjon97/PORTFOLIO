/*
Author: Jonathan Lander
Date: 4/12/17
Project: Sorting Algorithms
*/
#include "stdafx.h"
#include "Sort.h"
//default constructor does nothing.
QuickSort::QuickSort() {

}
//note that left takes a the first value of the elements and right takes last value of elements
QuickSort::QuickSort(int *ptrArray, int left, int right) {
	//checks for high low then called the partion method. See line 18
	if (left < right) {
		int p = Partition(ptrArray, left, right);
		//recursively calling quicksort otherwise the whole pointer will not fully be gone through.
		QuickSort(ptrArray, left, p - 1);
		QuickSort(ptrArray, p + 1, right);

	}

}
//partition method tests to see if the right number is greater than each elements in array
//if it isnt then it will swap them.
int QuickSort::Partition(int *ptrArray, int left, int right) {
	pivot = ptrArray[right];
	i = left - 1;
	holder = 0;
	for (j = left; j <= right - 1; j++) {
		if (ptrArray[j] <= pivot) {
			i = i + 1;
			//swapping
			holder = ptrArray[i];
			ptrArray[i] = ptrArray[j];
			ptrArray[j] = holder;
		}

	}
	holder = ptrArray[i + 1];
	ptrArray[i + 1] = ptrArray[right];
	ptrArray[right] = holder;
	return i + 1;

}
//Default constructor is not used
Bubble::Bubble() {
}

//Bubble just tests to see if the elements beside the choosen elements is bigger or smaller then swaps
//Then accordingly
Bubble::Bubble(int *ptrArray, int elements) {
	//swapped is just used to work the while loop
	swapped = false;
	while (!swapped) {
		for (i = 0; i < elements - 1; i++) {
			//testing if pointer i is greater than the pointer beside it
			if (*(ptrArray + i) > *(ptrArray + i + 1)) {
				//if it is it is swapped:
				temp = *(ptrArray + i);
				*(ptrArray + i) = *(ptrArray + i + 1);
				*(ptrArray + i + 1) = temp;
				swapped = false;
				break;
			}
			swapped = true;
		}
	}
}
//Default constructor is not used
Insertion::Insertion() {

}
//Insertion takes the pointer and number of elements entered
Insertion::Insertion(int *ptrArray, int elements) {
	//the variables are labeled appropriatly to what they are used for
	holePosition = 0;
	valueToInsert = 0;
	//the for loop goes through the array
	for (int i = 0; i < elements; i++) {
		valueToInsert = ptrArray[i];
		holePosition = i;
		//another loop tests to see if holeposition is greater than the current pointer
		while (holePosition > 0 && ptrArray[holePosition - 1] > valueToInsert) {
			ptrArray[holePosition] = ptrArray[holePosition - 1];
			holePosition = holePosition - 1;
		}
		//since it is being passed by reference it doesnt need to have a return value.
		ptrArray[holePosition] = valueToInsert;
	}
}
